<div class="datatables-inner-loader">
    <i class='fas fa-circle-notch fa-spin'></i>
</div>