<?php $__env->startComponent('mail::message'); ?>	
<table>
	<tr>
		<th style="text-align:left">Name</th>
		<td><?php echo e($user->first_name.' '.$user->last_name); ?></td>
	</tr>
	<tr>
		<th style="text-align:left">Email</th>
		<td><?php echo e($user->email); ?></td>
	</tr>
	<tr>
		<th style="text-align:left">Phone</th>
		<td><?php echo e(maskPhoneInUsFormat($user->phone)); ?></td>
	</tr>
	<tr>
		<th style="text-align:left">Organization</th>
		<td><?php echo e(!empty($user->organization) ? $user->organization->name : null); ?></td>
	</tr>
	<tr>
		<th style="text-align:left;vertical-align:top;">Message</th>
		<td><?php echo e($description); ?></td>
	</tr>
</table>
<br>
<br>
<p>Thanks,</p>
<p><?php echo e(config('app.name')); ?></p>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/email_template/contact_us.blade.php ENDPATH**/ ?>