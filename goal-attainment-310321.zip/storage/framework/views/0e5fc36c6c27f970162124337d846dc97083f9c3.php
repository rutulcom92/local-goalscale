<?php $__env->startSection('title','WMU |  Admin Profile'); ?>
<?php $__env->startSection('content'); ?>
<div class="Wrap_all_class padzero">
    <div class="Wrap_all_class_inner paddtopbtm">
        <?php echo e(Form::open(array('route'=>'admin.profile.update','id'=>'admin'))); ?>

        <input type="hidden" name="id" class="admin_id" value="<?php echo e(isset($id) ? $id : null); ?>">
    	<div class="add_edit_top_bar">
        	<div class="row">
        		<div class="col-sm-6">
        			<div class="add_edit_top_bar_left forupload_csuser" id="profPic">
        				<div class="user_prof_pic" id="cheoseFile">
        					<a href="javascript:void(0);">
	    						<div class="<?php echo e((isset($admin->image)  && ($admin->image != "")) ? "" : "formid_cqw"); ?>">
		    						<?php if(isset($admin->image) && ($admin->image != "" )): ?> 
		    						<img src="<?php echo e($admin->image); ?>" id="output_image">
		    						<?php else: ?>
		    						<span><img src="<?php echo e(asset('images/icon-upload.svg')); ?>" id="output_image"></span>
		        					<p>Upload photo</p>
		    						<?php endif; ?>
	    						</div>
	        				</a>
        				</div>
        				<input type="file" name="user_image" class="profilePic" accept="image/*">
        				<div class="for_right_name">
        					<?php if(isset($id)): ?>
        						<h5>Admin</h5>
	        					<h2><?php echo e(isset($admin->full_name) ? $admin->full_name : null); ?></h2>
	        					<p>Last login: <?php echo e(isset($admin->last_login) ? lastLoginDisplay($admin->last_login) : null); ?></p>
	        				<?php endif; ?>
        				</div>
        			</div>
        		</div>
        		<div class="col-sm-6">
        			<div class="right_bar_top_profile">
        				<h4><a href="<?php echo e(route('dashboard')); ?>" id="closed"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></h4>
        				<h4>
        					<input type="submit" class="btn-cls mrg-top" value="Save Changes">
        				</h4>
        			</div>
        		</div>
        	</div>
        </div>

        <div class="full_width Tabs_cls_cool marg40">
            <nav>
                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                    <a class="nav-item nav-link active" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
					<!-- <a class="nav-item nav-link" id="nav-labels-tab" data-toggle="tab" href="#nav-labels" role="tab" aria-controls="nav-labels" aria-selected="false">Labels</a> -->
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                	<?php echo $__env->make('dashboard.partials._admin-profile-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                 
                </div>
				<!-- <div class="tab-pane fade" id="nav-labels" role="tabpanel" aria-labelledby="nav-labels-tab">
                    <?php echo $__env->make('dashboard.partials._admin-labels-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div> -->
            </div>
        </div>
        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
    <script src="<?php echo e(asset('js/pages/dashboard/admin/profile.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-without-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/dashboard/admin-profile.blade.php ENDPATH**/ ?>