<?php if(isset($id)): ?>
  <?php $__env->startSection('title','WMU |  Edit Admin'); ?>
<?php else: ?>
  <?php $__env->startSection('title','WMU |  Add New Admin'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="Wrap_all_class padzero">
    <div class="Wrap_all_class_inner paddtopbtm">
      <?php if(isset($id)): ?>
      <?php echo e(Form::open(array('route' => array('admin.update', $id), 'id' => 'admin'))); ?>

        <?php echo method_field('PUT'); ?>
      <?php else: ?>
      <?php echo e(Form::open(array('route'=>'admin.store','id'=>'admin'))); ?>

      <?php endif; ?>
      <input type="hidden" id="admin_id" value="<?php echo e(isset($id) ? $id : null); ?>">
        <div class="add_edit_top_bar">
          <div class="row">
            <div class="col-sm-6">
              <div class="add_edit_top_bar_left forupload_csuser" id="profPic">
                <div class="user_prof_pic" id="cheoseFile">
                  <a href="javascript:void(0);">
                  <div class="<?php echo e((isset($orgAdmin->image)  && ($orgAdmin->image != "")) ? "" : "formid_cqw"); ?>">
                    <?php if(isset($orgAdmin->image) && ($orgAdmin->image != "" )): ?> 
                    <img src="<?php echo e($orgAdmin->image); ?>" id="output_image">
                    <?php else: ?>
                    <span><img src="<?php echo e(asset('images/icon-upload.svg')); ?>" id="output_image"></span>
                      <p>Upload photo</p>
                    <?php endif; ?>
                  </div>
                  </a>
                </div>
                <input type="file" name="user_image" class="profilePic">
                <div class="for_right_name">
                  <?php if(isset($id)): ?>
                    <h5>Admin</h5>
                    <h2><?php echo e(isset($orgAdmin->full_name) ? $orgAdmin->full_name : null); ?></h2>
                    <p>Last login: <?php echo e(isset($orgAdmin->last_login) ? lastLoginDisplay($orgAdmin->last_login) : null); ?></p>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="right_bar_top_profile">
                <h4><a href="javascript:void(0);" id="closed"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a>
                <input type="hidden" id="backUrl" name="url" value="<?php echo e(route('organization.index')); ?>"></h4>
                <h4><!-- <a href="javascript:void(0);" class="btn-cls mrg-top">Save Changes</a> -->
                  <input type="submit" class="btn-cls mrg-top" value="Save Changes">
                </h4>
              </div>
            </div>
          </div>
        </div>

        <div class="full_width Tabs_cls_cool marg40">
            <nav>
                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                    <a class="nav-item nav-link active" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                  <div class="form_field_cls">
      <div class="full_width">
        <div class="row">
          <div class="col-sm-3">
              <div class="form-group">
                <?php echo e(Form::label('First Name *')); ?>

                <?php echo e(Form::text('users[first_name]', isset($orgAdmin->first_name) ? $orgAdmin->first_name : null, array('class'=>'input_control','placeholder'=>'First name'))); ?>

              </div>
          </div>
          <div class="col-sm-3">
              <div class="form-group">
                <?php echo e(Form::label('Last Name *')); ?>

                <?php echo e(Form::text('users[last_name]', isset($orgAdmin->last_name) ? $orgAdmin->last_name : null, array('class'=>'input_control','placeholder'=>'Last name'))); ?>

              </div>
          </div>
        </div>
        </div>
        <div class="full_width">
          <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Organization *')); ?>

                  <?php echo e(Form::select('users[organization_id]', $organizations->toArray(), isset($orgAdmin->organization_id) ? $orgAdmin->organization_id : null ,array('class' => 'element_select'))); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Program *')); ?>

                    <select name="user_programs[program_id][]" class="multi_select_element sel_programs" multiple="multiple" data-tags="true", data-placeholder="Please Select">
                      <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(in_array($key,$selected_programs)): ?>
                          <option value="<?php echo e($key); ?>" selected="selected"><?php echo e($val); ?></option>
                        <?php else: ?>
                          <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
          </div>
        </div>
        <div class="full_width">
          <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Email *')); ?>

                  <?php echo e(Form::text('users[email]', isset($orgAdmin->email) ? $orgAdmin->email : null, array('class'=>'input_control','id'=>'adminEmail', 'placeholder'=>'Email'))); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Phone *')); ?>

                  <?php echo e(Form::text('users[phone]', isset($orgAdmin->phone) ? $orgAdmin->phone : null, array('class'=>'input_control mobile-input-mask','placeholder'=>'Phone'))); ?>

                </div>
            </div>
          </div>
        </div>
        <div class="full_width">
          <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Address *')); ?>

                  <?php echo e(Form::text('users[address]', isset($orgAdmin->address) ? $orgAdmin->address : null, array('class'=>'input_control','placeholder'=>'Address'))); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('City *')); ?>

                  <?php echo e(Form::text('users[city]', isset($orgAdmin->city) ? $orgAdmin->city : null, array('class'=>'input_control','placeholder'=>'City'))); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
              <?php echo e(Form::label('State *')); ?>

              <?php echo e(Form::select('users[state_id]', ['' => 'Please Select']+ $states->toArray(), isset($orgAdmin->state_id) ? $orgAdmin->state_id : null ,array('class' => 'element_select'))); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Zip *')); ?>

                  <?php echo e(Form::text('users[zip]', isset($orgAdmin->zip) ? $orgAdmin->zip : null, array('class'=>'input_control zip-input-mask','placeholder'=>'Zip'))); ?>

                </div>
            </div>
          </div>
        </div>
        <div class="full_width">
          <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Record # (enter N/A if not applicable)*')); ?>

                  <?php echo e(Form::text('users[record_num]', isset($orgAdmin->record_num) ? $orgAdmin->record_num : 0, array('class'=>'input_control','placeholder'=>'Record'))); ?>

                </div>
            </div>
          </div>
        </div>
        <div class="full_width separator_div"></div>
            <?php if(isset($id)): ?>
                <div class="full_width forgot_pass">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6>Set Password</h6>
                      <div class="form-group marg13">
                        <?php echo e(Form::label('Set Password')); ?>

                        <input type="password" name ="users[password]" class="input_control marg13" placeholder="New password" autocomplete="new-password">
                        <input type="password" name ="password_confirmation"  class="input_control" placeholder="Confirm new password">
                      </div>
                    </div>
                  </div>
                </div>
             <?php else: ?>
                <div class="full_width">
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="full_width">
                        <div class="custom-control custom-checkbox dfg ">
                            <label class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input business_To p_view " name="user_set_password" value="1" checked="">
                                <span class="custom-control-indicator"></span>
                                <div class="custom-control-description">Send the new user an email about their account and a password reset link</div>
                            </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            <?php endif; ?>
            </div>                  
        </div>
       </div>
      </div>
      <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/organization/administrator/add_edit.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-without-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/organization/partials/_add-edit-admin-section.blade.php ENDPATH**/ ?>