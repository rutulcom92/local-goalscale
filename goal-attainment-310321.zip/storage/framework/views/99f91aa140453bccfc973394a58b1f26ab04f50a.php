<?php $__env->startSection('title','WMU | Add New Organization'); ?>

<?php $__env->startSection('content'); ?>
 <div class="Wrap_all_class_inner paddtopbtm">
    <?php if(isset($id)): ?>
        <?php echo e(Form::open(array('route' => array('organization.update', $id), 'id' => 'organizationForm'))); ?>

        <?php echo method_field('PUT'); ?>
    <?php else: ?>
        <?php echo e(Form::open(array('route'=>'organization.store','id'=>'organizationForm'))); ?>

    <?php endif; ?>
    <input type="hidden" name="id" value="<?php echo e(isset($id) ? $id : null); ?>" id="organization_id">
        <div class="add_edit_top_bar">
        	<div class="row">
                <div class="col-sm-6">
                    <div class="add_edit_top_bar_left <?php echo e(isset($organization->logo_image) && ($organization->logo_image != NULL) ? '' : 'forupload_csuser'); ?>" id="profPic">
                        <div class="user_prof_pic" id="chooseFile">
                            <a href="javascript:void(0);">
                                <div class="formid_cqw">
                                <?php if(isset($organization->logo_image) && ($organization->logo_image != NULL )): ?> 
                                <img src="<?php echo e($organization->logo_image); ?>" id="organization_image">
                                <?php else: ?>
                                <span><img src="<?php echo e(asset('images/icon-upload.svg')); ?>" id="organization_image"></span>
                                    <p>Upload photo</p>
                                <?php endif; ?>
                                </div>
                            </a>
                        </div>
                        <input type="file" name="organization_logo" id="organization-logo" style="display: none;">
                        <!-- <input type="file" name="organization_image" class="profilePic"> -->
                        <div class="for_right_name">
                        <?php if(isset($id)): ?>
                            <h5>Organization</h5>
                            <h2><?php echo e(isset($organization->name) ? $organization->name : null); ?></h2>
                        <?php endif; ?>  
                        </div>
                    </div>
                </div>
        		<div class="col-sm-6">
        			<div class="right_bar_top_profile">
                         <h4><a href="javascript:void(0);" id="closed1"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></h4>
                        <input type="hidden" id="back_url" name="url" value="<?php echo e(route('organization.index')); ?>">  
        				<input type="submit" class="btn-cls mrg-top float-right" value="Save Changes">
        				</h4>
        			</div>
        		</div>
        	</div>
        </div>

        <div class="full_width Tabs_cls_cool marg40">
            <nav>
                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                    <a class="nav-item nav-link active" id="nav-details-tab" data-toggle="tab" href="#nav-details" role="tab" aria-controls="nav-details" aria-selected="true">Details</a>
                    <?php if(isset($id)): ?>
                    
                        <a class="nav-item nav-link" id="nav-programs-tab" data-toggle="tab" href="#nav-programs" role="tab" aria-controls="nav-programs" aria-selected="false">
                            <?php echo e(isset($organization->program_label) ? $organization->program_label.'s' : 'Programs'); ?>

                        </a>
                        
                        <a class="nav-item nav-link" id="nav-admin-tab" data-toggle="tab" href="#nav-admins" role="tab" aria-controls="nav-admins" aria-selected="false">
                            Administrators
                        </a>
                        
                        <a class="nav-item nav-link" id="nav-supervisors-tab" data-toggle="tab" href="#nav-supervisors" role="tab" aria-controls="nav-supervisors" aria-selected="false">
                            <?php echo e(isset($organization->supervisor_label) ? $organization->supervisor_label.'s' : 'Supervisors'); ?>    
                        </a>
                        
                        <a class="nav-item nav-link" id="nav-providers-tab" data-toggle="tab" href="#nav-providers" role="tab" aria-controls="nav-providers" aria-selected="false">
                            <?php echo e(isset($organization->provider_label) ? $organization->provider_label.'s' : 'Providers'); ?>

                        </a>
                        <a class="nav-item nav-link" id="nav-participants-tab" data-toggle="tab" href="#nav-participants" role="tab" aria-controls="nav-participants" aria-selected="false">
                            <?php echo e(isset($organization->participant_label) ? $organization->participant_label.'s' : 'Participants'); ?>

                        </a>

                        <a class="nav-item nav-link" id="nav-goals-tab" data-toggle="tab" href="#nav-goals" role="tab" aria-controls="nav-goals" aria-selected="false">Goals</a>

                        <a class="nav-item nav-link" id="nav-notes-tab" data-toggle="tab" href="#nav-notes" role="tab" aria-controls="nav-notes" aria-selected="false">Notes</a>

                        <a class="nav-item nav-link" id="nav-labels-tab" data-toggle="tab" href="#nav-labels" role="tab" aria-controls="nav-labels" aria-selected="false">Labels</a>

                        <!--  <a class="nav-item nav-link" id="nav-settings-tab" data-toggle="tab" href="#nav-settings" role="tab" aria-controls="nav-settings" aria-selected="false">Settings</a> -->
                    <?php endif; ?>
                </div>
               <!--  <div class="for_ty_export"><a href="javascript:void(0);"><img src="<?php echo e(asset('images/export.png')); ?>"> <span>Export Organization’s Data</span></a></div> -->
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-details" role="tabpanel" aria-labelledby="nav-details-tab">
                    <?php echo $__env->make('organization.partials._add-edit-details-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php if(isset($id)): ?>
                <div class="tab-pane fade" id="nav-admins" role="tabpanel" aria-labelledby="nav-admins-tab">
                    <?php echo $__env->make('organization.partials._list-admin-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="nav-programs" role="tabpanel" aria-labelledby="nav-programs-tab">
                    <?php echo $__env->make('organization.partials._add-edit-programs-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="nav-supervisors" role="tabpanel" aria-labelledby="nav-supervisors-tab">
                    <?php echo $__env->make('organization.partials._add-edit-supervisors-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="nav-providers" role="tabpanel" aria-labelledby="nav-providers-tab">
                    <?php echo $__env->make('organization.partials._add-edit-providers-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                </div>
                <div class="tab-pane fade" id="nav-participants" role="tabpanel" aria-labelledby="nav-participants-tab">
                    <?php echo $__env->make('organization.partials._add-edit-participants-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                </div>
                <div class="tab-pane fade" id="nav-goals" role="tabpanel" aria-labelledby="nav-goals-tab">
                    <?php echo $__env->make('organization.partials._add-edit-goals-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="nav-notes" role="tabpanel" aria-labelledby="nav-notes-tab">
                    <?php echo $__env->make('organization.partials._add-edit-notes-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="nav-labels" role="tabpanel" aria-labelledby="nav-labels-tab">
                    <?php echo $__env->make('organization.partials._add-edit-labels-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
               <!--  <div class="tab-pane fade" id="nav-settings" role="tabpanel" aria-labelledby="nav-settings-tab">
                    <?php echo $__env->make('organization.partials._add-edit-settings-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div> -->
                <?php endif; ?>
            </div>
        </div>
    <?php echo e(Form::close()); ?>    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/organization/program/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/organization/add_edit.js')); ?>" type="text/javascript"></script>
<?php if(isset($id)): ?>
<script src="<?php echo e(asset('js/pages/organization/supervisor/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/organization/provider/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/organization/participant/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/organization/administrator/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/organization/goal/index.js')); ?>" type="text/javascript"></script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-without-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/organization/add-edit.blade.php ENDPATH**/ ?>