 

<?php if(isset($id)): ?>
    <?php $__env->startSection('title','WMU |  Edit Participant'); ?>
<?php else: ?>
    <?php $__env->startSection('title','WMU |  Add New Participant'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="Wrap_all_class padzero">
    <div class="Wrap_all_class_inner paddtopbtm">
    	<?php if(isset($id)): ?>
    	<?php echo e(Form::open(array('route' => array('participant.update', $id), 'id' => 'participant'))); ?>

        <?php echo method_field('PUT'); ?>
    	<?php else: ?>
    	<?php echo e(Form::open(array('route'=>'participant.store','id'=>'participant'))); ?>

    	<?php endif; ?>
    	<div class="participant_id" style="display: none;"><?php echo e(isset($id) ? $id : null); ?></div>
        <div class="add_edit_top_bar">
        	<div class="row">
        		<div class="col-sm-6">
        			<div class="add_edit_top_bar_left <?php echo e(isset($participant->image) && ($participant->image != NULL) ? '' : 'forupload_csuser'); ?>" id="profPic">
        				<div class="user_prof_pic" id="chooseFile">
        					<a href="javascript:void(0);">
        						<div class="formid_cqw">
        						<?php if(isset($participant->image) && ($participant->image != NULL )): ?> 
        						<img src="<?php echo e($participant->image); ?>" id="participant_image">
        						<?php else: ?>
        						<span><img src="<?php echo e(asset('images/icon-upload.svg')); ?>" id="participant_image"></span>
	        						<p>Upload photo</p>
        						<?php endif; ?>
        						</div>
        					</a>
        				</div>
        				<input type="file" name="user_image" class="profilePic">
        				<div class="for_right_name">
        				<?php if(isset($id)): ?>
        					<h5><?php echo e(isset($organization->participant_label) ? $organization->participant_label : 'Participant'); ?></h5>
        					<h2><?php echo e(isset($participant->full_name) ? $participant->full_name : null); ?></h2>
        					<p>Last login: <?php echo e(isset($participant->last_login) ? lastLoginDisplay($participant->last_login) : null); ?></p>
        				<?php endif; ?>	
        				</div>
        			</div>
        		</div>
        		<div class="col-sm-6">
        			<div class="right_bar_top_profile">
        				  <?php if(!isset($org_id)): ?>
                             <h4><a href="javascript:history.go(-1);" id="closed1"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></h4>
                            <input type="hidden" id="back_url" name="url" value="<?php echo e(route('participant.index')); ?>">
                        <?php else: ?>
                            <input type="hidden" id="back_url" name="url" value="<?php echo e(route('organization.edit', array($org_id))); ?>">
                            <h4><a href="javascript:history.go(-1);" id="closed"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></h4>
                        <?php endif; ?>
        				<h4> <input type="submit" class="btn-cls mrg-top" value="Save Changes"></h4>
        			</div>
        		</div>
        	</div>
        </div>

        <div class="full_width Tabs_cls_cool part_sec marg40">
            <nav>
                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                  <a class="nav-item nav-link active" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
                  <?php if(isset($id)): ?>
                  <a class="nav-item nav-link" id="nav-goals-tab" data-toggle="tab" href="#nav-goals" role="tab" aria-controls="nav-goals" aria-selected="false">Goals</a>
                  <?php endif; ?>
                  <a class="nav-item nav-link" id="nav-notes-tab" data-toggle="tab" href="#nav-notes" role="tab" aria-controls="nav-notes" aria-selected="false">Notes</a>
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                  	<?php echo $__env->make('participant.partials._add-edit-profile-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            
                </div>
                <div class="tab-pane fade" id="nav-goals" role="tabpanel" aria-labelledby="nav-goals-tab">
                    <?php echo $__env->make('participant.partials._add-edit-goal-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
                </div>
                <div class="tab-pane fade" id="nav-notes" role="tabpanel" aria-labelledby="nav-notes-tab">
                    <div class="notes_Uimain">
                    	<div class="form-group">
                    		<label>Add notes about this participant (these are private, only viewable by supervisors and providers)</label>
                    		<?php echo e(Form::textarea('users[notes]',isset($participant->notes) ? $participant->notes : null,array('class'=> 'clsheightarea' , 'id' => 'notes','placeholder'=>'Participant Notes'))); ?>

                    	</div>
                    </div>
                </div>
            </div>
        </div> 
        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/participant/add_edit.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/participant/goal/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-without-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/participant/add-edit.blade.php ENDPATH**/ ?>