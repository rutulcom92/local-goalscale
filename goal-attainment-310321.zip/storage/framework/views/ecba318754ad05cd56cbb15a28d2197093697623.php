<div class="goal_box_item_cls addgoalsf">
    <h4 class="titleheadgoal">Presenting Challenges</h4>
    <p>This is the presenting problem or challenge to overcome.</p>
    <div class="for_activity_box_listing full_width">
        <div class="full_width">
            <ul class="badge_listing_mvb selected-presenting-challenges">
            </ul>
        </div>
        <div class="full_width">
            <div class="add_set_divcls"><a href="javascript:void(0);" data-toggle="modal" data-target="#presentingChallengesModal"><i class="far fa-plus"></i> Add Presenting Challenges</a></div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/create/_presenting-challenges.blade.php ENDPATH**/ ?>