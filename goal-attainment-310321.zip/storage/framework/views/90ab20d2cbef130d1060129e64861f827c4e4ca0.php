<div class="goal_box_item_cls">
    <h4 class="titleheadgoal">Goal Details</h4>
    <div class="for_activity_box_listing setmrg full_width">
        <div class="full_width textarea_activity">
            <div class="form_field_cls full_width">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="form-group setmrg">
                            <label>Select Provider</label>
                            <select class="element_select goal-provider" name="goal[provider_id]">
                                <?php if(Auth::user()->user_type_id != 3): ?>
                                    <option value=" ">Select Provider</option>
                                <?php endif; ?>
                                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($provider->id); ?>"><?php echo e($provider->full_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <div class="form-group setmrg">
                            <label>Select Participant</label>
                            <select class="element_select goal-participant" name="goal[participant_id]" data-participants-ajax-url="<?php echo e(route('goal.provider.participants')); ?>">
                                <option value=" ">Select Participant</option>
                                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($participant->id); ?>"><?php echo e($participant->full_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/create/_goal-details.blade.php ENDPATH**/ ?>