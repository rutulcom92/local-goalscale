<?php if(!empty($goal->tags)): ?>
    
    <?php
        $tagsStr = implode(', ', $goal->tags()->orderBy('tag','ASC')->pluck('tag')->toArray());
    ?>

    <?php if(strlen($tagsStr) > 15): ?>
        
        <?php
            $popoverContent = '<ul class=badge_listing_mvb>';
            foreach ($goal->tags as $key => $value) {
                $popoverContent .= '<li><span>'.$value->tag.'</span></li>';
            }
            $popoverContent .= '</ul>';

            $tagsStr = substr($tagsStr, 0, 15);
        ?>

        <?php echo e($tagsStr.'...'); ?>

        <a tabindex="0"
            class="dt-view-all-tags" 
            role="button" 
            data-html="true" 
            data-toggle="popover" 
            data-trigger="focus" 
            title="Tags for - <?php echo e($goal->name); ?>"
            data-content="<?php echo e($popoverContent); ?>">
            View all
        </a>
    <?php else: ?>
        <?php echo e($tagsStr); ?>

    <?php endif; ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/datatables/tags-column.blade.php ENDPATH**/ ?>