<div class="modal challenges_pop_cl fade" id="goalTopicsModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Goal Topics <span>Select all that apply</span></h4>
                <div class="pop_hd_btn">
                    <button type="button" class="close btn-cls dlminwidthy" data-dismiss="modal">Cancel</button>
                    <input type="button" class="pop_sb_btn btn-cls dlminwidthy save-goal-topics" value="Submit">
                </div>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="pop_src">
                    <div class="full_width">
                        <input type="text" class="input_clso srch goal-topics-search" placeholder="Search">
                    </div>
                    <div class="acc_main goal-topics-primary-container">
                        <div id="goalTopicsAccordion" class="accordion">
                            
                            <?php $__currentLoopData = $orgTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgTypeKey => $orgType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="card">
                                    <div class="card-header collapsed" data-toggle="collapse" href="#collapseGoalTopicsOrgType<?php echo e($orgType->id); ?>">
                                        <a class="card-title"><?php echo e($orgType->name); ?></a>
                                    </div>
                                    <div id="collapseGoalTopicsOrgType<?php echo e($orgType->id); ?>" class="card-body collapse">
                                        <div class="check_col">
                                            
                                            <?php $__currentLoopData = $orgType->goalTopicTags->sortBy('tag')->groupBy('group.name')->sortKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagGroup => $tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="eq_col">
                                                    <div class="acc_inner_col">
                                                        <?php if(!empty($tagGroup)): ?>
                                                            <h3 class="col_ttl"><?php echo e($tagGroup); ?></h3>
                                                        <?php endif; ?>

                                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagKey => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="ch_row goal-topics-checkbox-container">
                                                                <label class="custom-control custom-checkbox">
                                                                    <input type="checkbox" class="custom-control-input goal-topics-checkbox" name="goal[tags][<?php echo e($tag->id); ?>]" value="<?php echo e($tag->id); ?>">
                                                                    <span class="custom-control-indicator"></span>
                                                                    <div class="custom-control-description"><?php echo e($tag->tag); ?></div>
                                                                </label>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/edit/modals/_goal-topics-modal.blade.php ENDPATH**/ ?>