<div class="goal_box_item_cls">
    <h4 class="titleheadgoal">Scaling</h4>
    <div class="for_scaling_box_listing">
        <ul>
            <?php if(Auth::user()->user_type_id == superAdminUserTypeId() || Auth::user()->user_type_id == supervisorUserTypeId()): ?>
                <?php $__currentLoopData = goalScale(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <span><?php echo e($value); ?></span>
                        <p>
                            <textarea class="dectextarea goal-scale-description" placeholder="Enter description..." name="goal[scale][<?php echo e($key); ?>]"><?php echo e((!empty($goal_detail->scales()->where('value',strval($value))->first()) ? $goal_detail->scales()->where('value',strval($value))->first()->description : '' )); ?></textarea>
                        </p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = goalScale(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <span><?php echo e($value); ?></span>
                        <p>
                            <?php echo e((!empty($goal_detail->scales()->where('value',strval($value))->first()) ? $goal_detail->scales()->where('value',strval($value))->first()->description : '' )); ?>

                        </p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/edit/_scaling.blade.php ENDPATH**/ ?>