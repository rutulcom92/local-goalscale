<?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-sm-3">
		<div class="form-group">
		<?php echo e(Form::label($val['program_name'].' Provider *')); ?>

			<select name="participant_provider[provider_id][]" class="select2-element sel_providers" placeholder="Please Select" multiple="multiple">
				<option value="">Please Select</option>
				<?php $__currentLoopData = $val['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($provider->id); ?>,<?php echo e($val['program_id']); ?>"><?php echo e($provider->full_name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\wamp64\www\goal-attainment\resources\views/participant/select-participant-providers.blade.php ENDPATH**/ ?>