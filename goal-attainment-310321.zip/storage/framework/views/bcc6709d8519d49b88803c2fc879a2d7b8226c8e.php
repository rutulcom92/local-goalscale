<div class="full_width">
	<div class="full_width programUsersDt-custom-filters">
		<?php ($provider_label = isset($organization->provider_label) ? $organization->provider_label : 'Provider'); ?>
		<div class="wdth flt_right_rt">
			 <?php echo e(Form::select('filter_by_provider', [' ' => 'Filter by '.$provider_label]+ $providers->toArray(), null ,array('class' => 'datatable-custom-filter element_select', 'data-placeholder' => 'Filter by '.$provider_label, 'data-table-id' => 'programUsersDt'))); ?>

		</div>
		<div class="wdth flt_right_rt">
			<input type="text" placeholder="Search" class="input_clso srch datatable-common-search-input" data-table-id="programUsersDt">
		</div>
		<div class="float-right sdopcenrt">
			<a <?php if(isset($id)): ?> ? href="<?php echo e(route('participant.create',['pid' => $id])); ?>" <?php else: ?>  href="<?php echo e(route('participant.create')); ?>" <?php endif; ?> class="btn-cls float-right"> Add New Participant</a>
        </div>
	</div>
    <div class="full_width">
    	<div class="margtopz">
    		<?php echo $__env->make('loaders.datatables-inner-loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<table class="table dt-responsive nowrap dataTable no-footer" id="programUsersDt" style="width:100%" <?php if(isset($id)): ?> ? data-ajax-url="<?php echo e(route('program.user.list',['id' => $id])); ?>" <?php endif; ?>>
				<thead>
					<tr>
						<th>&nbsp;</th>
						<th>First Name</th>
						<th>Last Name</th>
						<th># of Goals</th>
						<th>Last Update</th>
						<th><?php echo e(isset($organization->provider_label) ? $organization->provider_label : 'Provider'); ?></th>
						<th>Goal Change</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php /**PATH C:\wamp64\www\goal-attainment\resources\views/program/partials/_add-edit-users-section.blade.php ENDPATH**/ ?>