<div class="goal_box_item_cls addgoalsf">
    <h4 class="titleheadgoal">Goal Topics</h4>
    <p>This is the subject or area of the goal on which you are working.</p>
    <div class="for_activity_box_listing full_width">
        <div class="full_width">
            <ul class="badge_listing_mvb selected-goal-topics">
            </ul>
        </div>
        <div class="full_width">
            <div class="add_set_divcls"><a href="javascript:void(0);" data-toggle="modal" data-target="#goalTopicsModal"><i class="far fa-plus"></i> Add Goal Topics</a></div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/create/_goal-topics.blade.php ENDPATH**/ ?>