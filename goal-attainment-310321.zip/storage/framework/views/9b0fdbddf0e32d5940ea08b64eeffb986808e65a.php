<div class="setting_dl_maintabs full_width">
    <div class="full_width">
        <h2>Personalization</h2>
        <div class="form-group uplosdfdfd">
            <label>Company Logo</label>
            <div class="upload_logo_UI">
                <a href="javascript:void(0);" class="upload-logo">
                    <?php if(isset($organization->logo_image) && ($organization->logo_image != NULL )): ?> 
                        <img src="<?php echo e($organization->logo_image); ?>" id="organization-logo-image" width="99%" height="97%" style="filter: none;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/icon-upload.svg')); ?>" id="organization-logo-image"><span>Upload your own logo</span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/organization/partials/_add-edit-settings-section.blade.php ENDPATH**/ ?>