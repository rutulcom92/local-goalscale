<?php $__env->startSection('title', pageTitle('Add New Goal')); ?>

<?php $__env->startSection('content'); ?>
<?php echo e(Form::open(['route' => 'goal.store', 'id' => 'goalForm'])); ?>


    <div class="Wrap_all_class padzero">
        <div class="Wrap_all_class_inner paddtopbtm">
            <div class="for_goal_UI_body_part">
                <?php if($errors->any()): ?>
                    <div class="server-side-form-erros alert alert-danger mrgTop25">
                        <p>Oops! Unable to add goal. There are items that require your attention:</p>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fas fa-exclamation-triangle"></i> <?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="full_width search_bar_top_part">
                            <div class="dofortypsvret">
                                <ul>
                                    <li>
                                        <a href="<?php echo e(route('goal.index')); ?>"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a>
                                    </li>
                                    <li><button type="submit" class="btn-cls dlminwidthy">Save</button></li>
                                </ul>
                            </div>
                            <input type="text" class="df_index_input" name="goal[name]" placeholder="Enter goal name...">                            
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <?php echo $__env->make('goal.create._scaling', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-sm-8">
                        <?php echo $__env->make('goal.create._goal-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('goal.create._presenting-challenges', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('goal.create._goal-topics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('goal.create._specialized-interventions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php echo $__env->make('goal.create.modals._presenting-challenges-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('goal.create.modals._goal-topics-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('goal.create.modals._specialized-interventions-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.mark.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/pages/goal/create.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-without-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/create/form.blade.php ENDPATH**/ ?>