<div class="form_field_cls">
	<div class="full_width">
  	<div class="row">
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('First Name *')); ?>

      			<?php echo e(Form::text('users[first_name]', isset($supervisor->first_name) ? $supervisor->first_name : null, array('class'=>'input_control','placeholder'=>'First name'))); ?>

      		</div>
  		</div>
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Last Name *')); ?>

      			<?php echo e(Form::text('users[last_name]', isset($supervisor->last_name) ? $supervisor->last_name : null, array('class'=>'input_control','placeholder'=>'Last name'))); ?>

      		</div>
  		</div>
  	</div>
	</div>
	<div class="full_width">
  	<div class="row">
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Organization *')); ?>

      			<?php echo e(Form::select('users[organization_id]', ['' => 'Please Select']+ $organizations->toArray(), isset($supervisor->organization_id) ? $supervisor->organization_id : (isset($org_id) ? $org_id : null) ,array('class' => 'element_select supervisor_organization','data-get-spervisor-programs-ajax-url' => route('supervisor.get-organization-programs')))); ?>

      		</div>
  		</div>
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label(isset($organization->program_label) ? $organization->program_label.' *' : 'Program *')); ?>

				<select name="user_programs[program_id][]" class="multi_select_element sel_programs" multiple="multiple" data-tags="true", data-placeholder="Please Select">
					<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(in_array($key,$selected_programs)): ?>
							<option value="<?php echo e($key); ?>" selected="selected"><?php echo e($val); ?></option>
						<?php else: ?>
							<option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
      		</div>
  		</div>
  		<!-- <div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Role *')); ?>

      			<?php echo e(Form::select('userss[role_id]', array('' => 'Please Select', '1' => 'Role 1', '2' => 'Role 2'), isset($supervisor->role_id) ? $supervisor->role_id : null ,array('class' => 'element_select'))); ?>

      		</div>
  		</div> -->
  	</div>
	</div>
	<div class="full_width">
  	<div class="row">
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Email *')); ?>

      			<?php echo e(Form::text('users[email]', isset($supervisor->email) ? $supervisor->email : null, array('class'=>'input_control','id'=>'supervisorEmail', 'placeholder'=>'Email'))); ?>

      		</div>
  		</div>
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Phone *')); ?>

      			<?php echo e(Form::text('users[phone]', isset($supervisor->phone) ? $supervisor->phone : null, array('class'=>'input_control mobile-input-mask','placeholder'=>'Phone'))); ?>

      		</div>
  		</div>
  	</div>
	</div>
	<div class="full_width">
		<div class="row">
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Address *')); ?>

      			<?php echo e(Form::text('users[address]', isset($supervisor->address) ? $supervisor->address : null, array('class'=>'input_control','placeholder'=>'Address'))); ?>

      		</div>
  		</div>
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('City *')); ?>

      			<?php echo e(Form::text('users[city]', isset($supervisor->city) ? $supervisor->city : null, array('class'=>'input_control','placeholder'=>'City'))); ?>

      		</div>
  		</div>
  		<div class="col-sm-3">
      		<div class="form-group">
  			<?php echo e(Form::label('State *')); ?>

  			<?php echo e(Form::select('users[state_id]', ['' => 'Please Select']+ $states->toArray(), isset($supervisor->state_id) ? $supervisor->state_id : null ,array('class' => 'element_select'))); ?>

      		</div>
  		</div>
  		<div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Zip *')); ?>

      			<?php echo e(Form::text('users[zip]', isset($supervisor->zip) ? $supervisor->zip : null, array('class'=>'input_control zip-input-mask','placeholder'=>'Zip'))); ?>

      		</div>
  		</div>
		</div>
	</div>
	<div class="full_width">
		<div class="row">
			<div class="col-sm-3">
				<div class="form-group">
					<?php echo e(Form::label('Record # (enter N/A if not applicable)*')); ?>

					<?php echo e(Form::text('users[record_num]', isset($supervisor->record_num) ? $supervisor->record_num : 0, array('class'=>'input_control','placeholder'=>'Record'))); ?>

				</div>
			</div>
			<div class="col-sm-3">
				<div class="form-group">
					<?php echo e(Form::label('Race/Ethnicity')); ?>

					<?php echo e(Form::select('users[ethnicity]', ['' => 'Please Select','American Indian Or Alaska Native' => 'American Indian Or Alaska Native','Asian' => 'Asian','Black Or African American' => 'Black Or African American','Hispanic Or Latino' => 'Hispanic Or Latino','I Don\'t Wish To Answer' => 'I Don\'t Wish To Answer','Native Hawaiian Or Other Pecific Islander' => 'Native Hawaiian Or Other Pecific Islander','Two Or More Races' => 'Two Or More Races','White' => 'White'], isset($supervisor->ethnicity) ? $supervisor->ethnicity : null ,array('class' => 'element_select'))); ?>

				</div>
			</div>
		</div>
	</div>
	<div class="full_width separator_div"></div>
      <?php if(isset($id)): ?>
          <div class="full_width forgot_pass">
            <div class="row">
              <div class="col-sm-3">
                <h6>Set Password</h6>
                <div class="form-group marg13">
                  <?php echo e(Form::label('Set Password')); ?>

                  <input type="password" name ="users[password]" class="input_control marg13" placeholder="New password" autocomplete="new-password">
                  <input type="password" name ="password_confirmation"  class="input_control" placeholder="Confirm new password">
                </div>
              </div>
            </div>
          </div>
          <?php if(Auth::user()->isSuperAdmin() == true  || Auth::user()->isOrganizationAdmin()): ?>
            <div class="full_width">
              <div class="row">
                  <div class="col-sm-6">
                    <div class="full_width">
                          <div class="custom-control custom-checkbox dfg ">
                                <label class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input business_To p_view " name="inactive_user" value="1" <?php if($supervisor->is_active == 0): ?> checked="" <?php endif; ?>>
                                    <span class="custom-control-indicator"></span>
                                    <div class="custom-control-description">User Inactive</div>
                                </label>
                            </div>
                        </div>
                  </div>
                </div>
            </div>
          <?php endif; ?>
       <?php else: ?>
          <div class="full_width">
            <div class="row">
              <div class="col-sm-6">
                <div class="full_width">
                  <div class="custom-control custom-checkbox dfg ">
                      <label class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input business_To p_view " name="user_set_password" value="1" checked="">
                          <span class="custom-control-indicator"></span>
                          <div class="custom-control-description">Send the new user an email about their account and a password reset link</div>
                      </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
      <?php endif; ?>

</div> <?php /**PATH C:\wamp64\www\goal-attainment\resources\views/supervisor/partials/_add-edit-profile-section.blade.php ENDPATH**/ ?>