

<?php $__env->startSection('title','WMU | View Goal'); ?>

<?php $__env->startSection('content'); ?>
<div class="Wrap_all_class padzero">
    <div class="Wrap_all_class_inner paddtopbtm">
        <div class="for_goal_top_panle_cls">
        	<div class="row align-items-center">
        		<div class="col-sm-8">
        			<div class="for_title_goal_UIclsd">
        				<h2><?php echo e($goal_detail->name); ?></h2>
        				<div class="for_tags_cls_goal">
        					<label>Tags:</label>
        					<?php echo $__env->make('goal.view._goal-tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        				</div>
        			</div>
        		</div>
        		<div class="col-sm-4">
        			<div class="right_bar_top_profile for_ctc_goal_UI">
        				<ul>
                            <?php if($goal_detail->status_id != goalCloseStatusId() && (Auth::user()->user_type_id == superAdminUserTypeId() || Auth::user()->user_type_id == providerUserTypeId())): ?>
        					   <li><a href="" class="sm_nwUIbtn close_goal" data-get-goal-close-url = "<?php echo e(route('goal.change-status-close',$goal_detail->id)); ?>">Discontinue Goal</a></li>
                            <?php endif; ?>
                            <?php if(Auth::user()->user_type_id == superAdminUserTypeId()): ?>
                                <?php echo e(Form::open(array('route' => array('goal.details.export', $goal_detail->id), 'id' => 'goalExportForm', 'files' => 'true'))); ?>

                                <input type="hidden" id="goalGraph" name="goalgrp">
                                <li><buttton type="button" id="export-to-pdf" class="sm_nwUIbtn">Export to PDF</button></li>
                            <?php echo e(Form::close()); ?>

                            <?php endif; ?>

                            <?php if(Auth::user()->user_type_id == superAdminUserTypeId() || Auth::user()->user_type_id == supervisorUserTypeId()): ?>
                                <li class="btn-edit-goal"><buttton type="button" onclick='window.location.href="<?php echo e(route('goal.edit',$goal_detail->id)); ?>"' class="sm_nwUIbtn ml-10">Edit Goal</button></li>
                            <?php endif; ?>
                            <li><a class="mrg-left" href="javascript:void(0);" id="closed"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></li>

        				</ul>
        			</div>
        		</div>
        	</div>
        </div>
        <div class="for_goal_UI_body_part">
        	<div class="row">
        		<div class="col-sm-12">
        			<div class="goal_box_item_cls">
                    <div class="for_floating_divchart">
                        <h4 class="titleheadgoal">Goal progress</h4>
                        <div class="forset_rightdr_user">
                            <div class="for_comment_showdiv">
                                <div class="user_avtar_comment"><img src="<?php echo e($goal_detail->participant->image); ?>"></div>
                                <div class="comment_details_user_NWUI">
                                    <h5 class="full_width blue_user">Participant</h5>
                                    <h6 class="full_width" id="participant-name"><?php echo e($goal_detail->participant->full_name); ?></h6>
                                </div>
                            </div>
                            <div class="for_comment_showdiv">
                                <div class="user_avtar_comment"><img src="<?php echo e($goal_detail->provider->image); ?>"></div>
                                <div class="comment_details_user_NWUI">
                                    <h5 class="full_width orange_user">Provider</h5>
                                    <h6 class="full_width"  id="provider-name"><?php echo e($goal_detail->provider->full_name); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>

        				<div class="full_width">
                            <div id="goalprogress"></div>
                        </div>
        			</div>
        		</div>
        		<div class="col-sm-4">
        			<div class="goal_box_item_cls">
        				<h4 class="titleheadgoal">Scaling</h4>
        				<div class="for_scaling_box_listing">
        					<?php echo $__env->make('goal.view._goal-scalling', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        				</div>
        			</div>
        		</div>
        		<div class="col-sm-8">
        			<div class="goal_box_item_cls">
        				<h4 class="titleheadgoal">Activity</h4>
                        <?php echo $__env->make('goal.view._goal-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        			</div>
        		</div>
        	</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/goal/edit.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-without-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/view/form.blade.php ENDPATH**/ ?>