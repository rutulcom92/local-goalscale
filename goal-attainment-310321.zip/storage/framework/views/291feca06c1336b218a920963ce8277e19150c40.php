 <div class="form_field_cls">
	<div class="full_width">
		<div class="wdth">
			<input type="text" placeholder="Search" class="input_clso srch datatable-common-search-input"  data-table-id="providerGoalsDt">
		</div>
	</div>
</div>   
<div class="full_width margtopz">
	<?php echo $__env->make('loaders.datatables-inner-loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<table id="providerGoalsDt" class="table dt-responsive nowrap" style="width:100%" <?php if(isset($id)): ?> ? data-ajax-url="<?php echo e(route('provider.goal.list',['id' => $id])); ?>" <?php endif; ?>">
		<thead>
			<tr>
				<th>Goal Title</th>
				<th><?php echo e(isset($organization->participant_label) ? $organization->participant_label : 'Participant'); ?></th>
				<th>Date Created</th>
				<th>Last Update</th>
				<th>Tags</th>
				<th>Goal Change</th>
				<th>Status</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>    <?php /**PATH C:\wamp64\www\goal-attainment\resources\views/provider/partials/_add-edit-goal-section.blade.php ENDPATH**/ ?>