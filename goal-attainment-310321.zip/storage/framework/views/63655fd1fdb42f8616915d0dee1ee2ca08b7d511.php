<select name="user_programs[program_id][]" class="multi_select_element sel_programs" multiple="multiple" data-tags="true", data-placeholder="Please Select">
	<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/provider/select-organization-programs.blade.php ENDPATH**/ ?>