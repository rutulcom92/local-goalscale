<div class="notes_Uimain">
	<div class="form-group">
		<label>Add notes about this organization (these are private, only viewable by an admin)</label>
		<textarea class="clsheightarea" placeholder="Organization Notes" name="organization[notes]" cols="50" rows="10"><?php echo e(isset($organization->notes) ? $organization->notes : null); ?></textarea>
	</div>
	<span></span>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/organization/partials/_add-edit-notes-section.blade.php ENDPATH**/ ?>