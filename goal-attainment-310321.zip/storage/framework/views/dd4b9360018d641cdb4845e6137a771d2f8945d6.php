<?php $__env->startSection('title', pageTitle('Forbidden')); ?>
<?php $__env->startSection('code', '403'); ?>
<?php $__env->startSection('message', __($exception->getMessage() ?: 'Forbidden')); ?>
<?php $__env->startSection('error-description', "You don't have permission to access this area"); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/errors/403.blade.php ENDPATH**/ ?>