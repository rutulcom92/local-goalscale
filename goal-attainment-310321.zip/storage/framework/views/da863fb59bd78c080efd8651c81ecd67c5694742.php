<?php $__env->startSection('title','WMU | Supervisor'); ?>

<?php $__env->startSection('content'); ?>
<div class="Wrap_all_class">
   <div class="Wrap_all_class_inner">
        <div class="top_filter">
        	<div class="row">
        		<div class="col-sm-3">
        			<h1>Supervisors</h1>
        		</div>	
        		<div class="col-sm-9">
        			<div class="filter_cls_wmu">
        				<ul class="supervisorsDt-custom-filters">
        					<li class="mrg-left">
        						<a href="<?php echo e(route('supervisor.create')); ?>" class="btn-cls">Add New Supervisor</a>
        					</li>
        					<li class="mrg-left wdth">
                                <?php echo e(Form::select('filter_by_program', [' ' => 'Filter by Program']+ $programs->toArray(), null ,array('class' => 'datatable-custom-filter element_select', 'data-placeholder' => 'Filter by Program', 'data-table-id' => 'supervisorsDt'))); ?>

        					</li>
                            <li class="mrg-left wdth">
                                <?php echo e(Form::select('filter_by_organization', [' ' => 'Filter by Organization']+ $organizations->toArray(), null ,array('class' => 'datatable-custom-filter element_select', 'data-placeholder' => 'Filter by Organization', 'data-table-id' => 'supervisorsDt'))); ?>

                            </li>
        					<li class="mrg-left wdth">
        						<input type="text" placeholder="Search" class="input_clso srch datatable-common-search-input" data-table-id="supervisorsDt">
        					</li>
        				</ul>
        			</div>
        		</div>	
        	</div>
        </div>
        <div class="for_content_section">
            <?php echo $__env->make('loaders.datatables-inner-loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        	<table id="supervisorsDt" class="table dt-responsive nowrap" style="width:100%" data-ajax-url="<?php echo e(route('supervisor.list')); ?>">
        		<thead>
        			<tr>
        				<th>&nbsp;</th>
        				<th>First Name</th>
        				<th>Last Name</th>
                        <th># of Providers</th>
        				<th># of Participants</th>
        				<th># of Participant’s Goals</th>
        				<th>Organization</th>
                        <th>Programs</th>
        				<th>Last Sign In</th>
        				<th>Goal Change</th>
                        <th>Status</th>
        			</tr>
        		</thead>
        		<tbody>
        			
        		</tbody>
        	</table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/supervisor/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/supervisor/index.blade.php ENDPATH**/ ?>