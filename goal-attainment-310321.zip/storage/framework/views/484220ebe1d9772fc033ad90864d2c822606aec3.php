 <?php $__env->startSection('title','WMU | Dashboard'); ?> <?php $__env->startSection('content'); ?>
<div class="Wrap_all_class">
    <div class="Wrap_all_class_inner">
        <div class="dashboard_cls_UI_main full_width">
            <div class="row">
                <div class="col-sm-6">
                    <?php if(Auth::user()->user_type_id == 1): ?>
                    <a class="edxdit_opt add-edit-welcomecontent" data-url="<?php echo e(route('dashboard.welcome-to-goal.create')); ?>"><img src="<?php echo e(asset('images/icon-edit.svg')); ?>" /></a>
                    <?php endif; ?>
                    <div class="full_width box_WMUUI marg40">
                        <h1 class="welcome-heading-content"><?php echo e((!empty(getSiteConfig('welcome_heading')) ? getSiteConfig('welcome_heading') : 'Welcome to Goal Attainment Scaling!')); ?></h1>
                        <?php if(!empty(getSiteConfig('welcome_to_goal_attainment_scaling'))): ?>
                        <p class="welcome-content"><?php echo e(getSiteConfig('welcome_to_goal_attainment_scaling')); ?></p>
                        <?php else: ?>
                        <p class="welcome-content">
                            GAS is a method of measuring goal attainment over time, using a five-point scale to capture all possible outcomes for a given goal. GAS is a unique approach to goal setting, one that promotes success along a
                            continuum rather than the traditional all-or-nothing success vs. failure model. It has been used in healthcare and educational settings since 1968. Numerous studies have found GAS to be highly sensitive to
                            change, unlike other measures that use a generic and broad evaluation, not specific to the needs of each individual. The ability to capture small but meaningful change over time makes it a preferred outcome
                            measure among clinicians, researchers, teachers, and caregivers.
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="full_width box_WMUUI h390 box_WMUUI_innerT">
                        <?php echo e(Form::open(array('route'=>'dashboard.contactus','id'=>'contactus'))); ?>

                        <div class="row">
                            <div class="col-sm-8">
                                <h1>Contact Technical Support</h1>
                            </div>
                            <div class="col-sm-4">
                                <div class="top_bar_info_bar">
                                    <ul>
                                        <li>
                                            <a><img src="<?php echo e(asset('images/icon-email.svg')); ?>" /><span><?php echo e(config('constants.CONTACT_US_EMAIL')); ?></span></a>
                                        </li>
                                        <li>
                                            <a href="tel:<?php echo e(config('constants.CONTACT_US_PHONE')); ?>"><img src="<?php echo e(asset('images/icon-phone.svg')); ?>" /><span><?php echo e(config('constants.CONTACT_US_PHONE')); ?></span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="full_width form_field_cls mrtop18">
                                    <div class="form-group">
                                        <?php echo e(Form::textarea('contactus[messages]', null, array('class' => 'area_dash', 'placeholder' => 'To send a message for support on a technical issue or error, or to share an idea to improve this app, type here...'))); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="full_width">
                                    <input type="submit" class="btn-cls min-wdth text-center float-right" value="Send" />
                                </div>
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
                <div class="col-sm-6 mrbtd">
                    <?php if(Auth::user()->user_type_id == 1): ?>
                    <a class="edxdit_opt add-edit-aboutcontent" data-url="<?php echo e(route('dashboard.about-us.create')); ?>"><img src="<?php echo e(asset('images/icon-edit.svg')); ?>" /></a>
                    <?php endif; ?>
                    <div class="full_width box_WMUUI h390">
                        <h1 class="aboutus-heading-content"><?php echo e((!empty(getSiteConfig('about_us_heading')) ? getSiteConfig('about_us_heading') : 'About Us')); ?></h1>
                        <div class="full_width">
                            <div class="row">
                                <div class="col-sm-7">
                                    <?php if(!empty(getSiteConfig('about_us_content'))): ?>
                                    <p class="aboutus-content"><?php echo e(getSiteConfig('about_us_content')); ?></p>
                                    <?php else: ?>
                                    <p>
                                        GAS is a method of measuring goal attainment over time, using a five-point scale to capture all possible outcomes for a given goal. GAS is a unique approach to goal setting, one that promotes success
                                        along a continuum rather than the traditional all-or-nothing success vs. failure model. It has been used in healthcare and educational settings since 1968. Numerous studies have found GAS to be highly
                                        sensitive to change, unlike other measures that use a generic and broad evaluation, not specific to the needs of each individual. The ability to capture small but meaningful change over time makes it
                                        a preferred outcome measure among clinicians, researchers, teachers, and caregivers.
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-5">
                                    <div class="for_about_feature">
                                        <img
                                            class="about_us_image"
                                            src="<?php echo e((!empty(getSiteConfig('about_us_image')) ? url(Storage::url(config('constants.about_us_image_storage_path').getSiteConfig('about_us_image'))) : asset('images/2.jpg'))); ?>"
                                        />
                                        <h6 class="aboutus-image-content"><?php echo e((!empty(getSiteConfig('about_us_image_content')) ? getSiteConfig('about_us_image_content') : 'Ann Chapleau & Jennifer Harrison')); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.inputmask.bundle.js')); ?>" type="text/javascript"></script>

<script type="text/javascript">
    jQuery(".box_WMUUI p").mCustomScrollbar();
</script>
<script src="<?php echo e(asset('js/pages/dashboard/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/dashboard/index.blade.php ENDPATH**/ ?>