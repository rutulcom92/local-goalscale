<div class="form_field_cls">
	<div class="full_width">
		<div class="full_width">
		<div class="wdth flt_right_rt orgranizationProgramsDt-custom-filters">
			<input type="text" placeholder="Search" class="input_clso srch datatable-common-search-input" data-table-id="orgranizationProgramsDt">
		</div>
		<div class="float-right sdopcenrt">
			<a <?php if(isset($id)): ?> ? href="<?php echo e(route('program.create',['org_id' => $id])); ?>" <?php else: ?> href="<?php echo e(route('program.create')); ?>" <?php endif; ?> class="btn-cls">Add New <?php echo e(isset($organization->program_label) ? $organization->program_label : 'Program'); ?></a>
		</div>
			<div class="full_width margtopz">
				<?php echo $__env->make('loaders.datatables-inner-loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<table class="table dt-responsive nowrap dataTable no-footer" id="orgranizationProgramsDt" style="width:100%" <?php if(isset($id)): ?> ? data-ajax-url="<?php echo e(route('organization.program.list',['id' => $id])); ?>" <?php endif; ?> >
					<thead>
						<tr>
							<th><?php echo e(isset($organization->program_label) ? $organization->program_label : 'Program'); ?> Name</th>
							<th><?php echo e(isset($organization->supervisor_label) ? $organization->supervisor_label.'s' : 'Supervisors'); ?></th>
							<th># of <?php echo e(isset($organization->provider_label) ? $organization->provider_label.'s' : 'Providers'); ?></th>
							<th># of <?php echo e(isset($organization->participant_label) ? $organization->participant_label.'s' : 'Participants'); ?></th>
							<th># of <?php echo e(isset($organization->participant_label) ? $organization->participant_label."'s" : "Participant's"); ?> Goals</th>
							<th>Last Update</th>
							<th>Avg Goal Change</th>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
	    </div>
	</div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/organization/partials/_add-edit-programs-section.blade.php ENDPATH**/ ?>