<div class="modal challenges_pop_cl fade" id="specializedInterventionsModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Specialized Interventions <span>Select all that apply</span></h4>
                <div class="pop_hd_btn">
                    <button type="button" class="close btn-cls dlminwidthy" data-dismiss="modal">Cancel</button>
                    <input type="button" class="pop_sb_btn btn-cls dlminwidthy save-specialized-interventions" value="Submit">
                </div>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="pop_src">
                    <div class="full_width">
                        <input type="text" class="input_clso srch specialized-interventions-search" placeholder="Search">
                    </div>
                    <div class="acc_main specialized-interventions-primary-container">
                        <div id="specializedInterventionsAccordion" class="accordion">
                            
                            <?php $__currentLoopData = $orgTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgTypeKey => $orgType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="card">
                                    <div class="card-header collapsed" data-toggle="collapse" href="#collapseSpecializedInterventionsOrgType<?php echo e($orgType->id); ?>">
                                        <a class="card-title"><?php echo e($orgType->name); ?></a>
                                    </div>
                                    <div id="collapseSpecializedInterventionsOrgType<?php echo e($orgType->id); ?>" class="card-body collapse">
                                        <div class="check_col">
                                            
                                            <?php $__currentLoopData = $orgType->specializedInterventionTags->sortBy('tag')->groupBy('group.name')->sortKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagGroup => $tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="eq_col">
                                                    <div class="acc_inner_col">
                                                        <?php if(!empty($tagGroup)): ?>
                                                            <h3 class="col_ttl"><?php echo e($tagGroup); ?></h3>
                                                        <?php endif; ?>

                                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagKey => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="ch_row specialized-interventions-checkbox-container">
                                                                <label class="custom-control custom-checkbox">
                                                                    <input type="checkbox" class="custom-control-input specialized-interventions-checkbox" name="goal[tags][<?php echo e($tag->id); ?>]" value="<?php echo e($tag->id); ?>">
                                                                    <span class="custom-control-indicator"></span>
                                                                    <div class="custom-control-description"><?php echo e($tag->tag); ?></div>
                                                                </label>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/edit/modals/_specialized-interventions-modal.blade.php ENDPATH**/ ?>