<?php $__env->startSection('title','WMU | Provider'); ?>

<?php $__env->startSection('content'); ?>
<div class="Wrap_all_class">
    <div class="Wrap_all_class_inner">
        <div class="top_filter formobile_screen">
        	<div class="row">
        		<div class="col-sm-2">
        			<h1>Providers</h1>
        		</div>	
        		<div class="col-sm-10">
        			<div class="filter_cls_wmu">
        				<ul class="providersDt-custom-filters">
        					<li class="mrg-left">
        						<a href="<?php echo e(route('provider.create')); ?>" class="btn-cls">Add New Provider</a>
        					</li>
        					<li class="mrg-left wdth">
        						<?php echo e(Form::select('filter_by_provider_type', [' ' => 'Filter by Provider Type']+ $provider_types->toArray(), null ,array('class' => 'datatable-custom-filter element_select', 'data-placeholder' => 'Filter by Provider Type', 'data-table-id' => 'providersDt'))); ?>

        					</li>
        					<li class="mrg-left wdth">
        						<?php echo e(Form::select('filter_by_program', [' ' => 'Filter by Program']+ $programs->toArray(), null ,array('class' => 'datatable-custom-filter element_select', 'data-placeholder' => 'Filter by Program', 'data-table-id' => 'providersDt'))); ?>

        					</li>
                            <?php if(Auth::user()->user_type_id == 1 || Auth::user()->user_type_id == 5): ?>
            					<li class="mrg-left wdth">
            						<?php echo e(Form::select('filter_by_organization', [' ' => 'Filter by Organization']+ $organizations->toArray(), null ,array('class' => 'datatable-custom-filter element_select', 'data-placeholder' => 'Filter by Organization', 'data-table-id' => 'providersDt'))); ?>

            					</li>
                            <?php endif; ?>
        					<li class="mrg-left wdth">
        						<input type="text" placeholder="Search" class="input_clso srch datatable-common-search-input" data-table-id="providersDt">
        					</li>
        				</ul>
        			</div>
        		</div>	
        	</div>
        </div>
        <div class="for_content_section">
            <?php echo $__env->make('loaders.datatables-inner-loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        	<table class="table dt-responsive nowrap" id="providersDt" style="width:100%" data-ajax-url="<?php echo e(route('provider.list')); ?>">
        		<thead>
        			<tr>
        				<th>&nbsp;</th>
        				<th>First Name</th>
        				<th>Last Name</th>
        				<th># of Participants</th>
        				<th># of Participant’s Goals</th>
        				<th>Organization</th>
                        <th>Program</th>
                        <th>Provider Type</th>
        				<th>Last Update</th>
        				<th>Goal Change</th>
                        <th>Status</th>
        			</tr>
        		</thead>
        		<!-- <tbody>
        			<tr>
        				<td><div class="for_user"><img src="<?php echo e(asset('images/1.jpg')); ?>"></div></td>
        				<td>Warren</td>
        				<td>Mills</td>
        				<td>22</td>
        				<td>201</td>
        				<td>Bronson Hospital</td>
        				<td>Sep 15, 2019</td>
        				<td>+3.2</td>
        			</tr>
        		</tbody> -->
        	</table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/provider/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/provider/index.blade.php ENDPATH**/ ?>