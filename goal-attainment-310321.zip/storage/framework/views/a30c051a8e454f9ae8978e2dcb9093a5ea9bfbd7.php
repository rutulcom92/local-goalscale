<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="top_user_general_info full_width">
		<div class="full_width">
			<div class="top_user_general_info_left">
				<div class="user_avtar_comment"><img src="<?php echo e($activity->owner->image); ?>"></div>
				<div class="comment_details_user_NWUI">
					<h5 class="full_width <?php if($activity->owner->user_type_id == 4): ?> blue_user <?php else: ?> orange_user <?php endif; ?>"><?php echo e($activity->owner->userType->name); ?></h5>
					<h6  class="full_width"><?php echo e($activity->owner->full_name); ?><span><?php echo e($activity->date_of_activity); ?></span></h6>
					<p  class="full_width"><?php echo e($activity->update_text); ?></p>
					<div class="for_replydiv full_width activity-replay-<?php echo e($activity->id); ?>"><a data-id="<?php echo e($activity->id); ?>" class="activity-replay" data-get-goal-activity-replay-ajax-url = "<?php echo e(route('goal.get-activity-replay',['id' => $activity->id ])); ?>" href="javascript:void(0);">Reply</a></div>
					<?php if(isset($activity->attachments) && count($activity->attachments) > 0): ?>
						<div class="for_repllabel full_width mrgtopbottmdj">Attachments</div>
						<div class="full_width attached_comm_add">
							<ul>
								<?php $__currentLoopData = $activity->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(in_array(strval($attachment->namestorage),config('constants.image_mimes'))): ?>
										<li>
											<img src="<?php echo e($attachment->name); ?>">
										</li>
									<?php else: ?>
										<li style="width: 100%"><a href="<?php echo e($attachment->name); ?>"><?php echo e($attachment->filename); ?></a></li>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="top_user_general_info_right">
				<p>Updated Progress</p>
				<div class="forPro_listingbar text-center">
					<span class="<?php if($activity->owner->user_type_id == 4): ?> blue_progress <?php else: ?> org_progress <?php endif; ?>"><?php echo e($activity->activity_ranking); ?></span>
				</div>
			</div>
			<div class="full_width padd_left_60">
				<?php $__currentLoopData = $activity->childActivities()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <div class="for_comment_showdiv">
						<div class="user_avtar_comment"><img src="<?php echo e($child->owner->image); ?>"></div>
						<div class="comment_details_user_NWUI">
							<h5 class="full_width <?php if($activity->owner->user_type_id == 4): ?> blue_user <?php else: ?> orange_user <?php endif; ?>"><?php echo e($child->owner->userType->name); ?></h5>
							<h6  class="full_width"><?php echo e($child->owner->full_name); ?><span><?php echo e($child->date_of_activity); ?></span></h6>
							<p  class="full_width"><?php echo e($child->update_text); ?></p>
						</div>
						<?php if(count($child->attachments) > 0): ?>
						   <div class="for_repllabel full_width mrgtopbottmdj">Attachments</div>
							<div class="full_width attached_comm_add">
								<ul>
									<?php $__currentLoopData = $child->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(in_array(mime_content_type($attachment->namestorage),config('constants.image_mimes'))): ?>
											<li>
												<img src="<?php echo e($attachment->name); ?>">
											</li>
										<?php else: ?>
											<li style="width: 100%"><a href="<?php echo e($attachment->name); ?>"><?php echo e($attachment->filename); ?></a></li>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						<?php endif; ?>
					</div>      									
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/view/_goal-get-activities.blade.php ENDPATH**/ ?>