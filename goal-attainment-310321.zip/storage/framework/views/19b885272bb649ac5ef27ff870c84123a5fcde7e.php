<?php $__env->startSection('title','WMU | Add New Program'); ?>

<?php $__env->startSection('content'); ?>
 <div class="Wrap_all_class_inner paddtopbtm">
    <?php if(isset($id)): ?>
        <?php echo e(Form::open(array('route' => array('program.update', $id), 'id' => 'programForm'))); ?>

        <?php echo method_field('PUT'); ?>
    <?php else: ?>
        <?php echo e(Form::open(array('route'=>'program.store','id'=>'programForm'))); ?>

    <?php endif; ?>
    <input type="hidden" name="id" value="<?php echo e(isset($id) ? $id : null); ?>" id="program_id">
        <div class="add_edit_top_bar">
        	<div class="row">
                <div class="col-sm-6">
                   <div class="add_edit_top_bar_left forupload_csuser" id="profPic">
                       <div class="user_prof_pic" id="chooseFile">
                            <a href="javascript:void(0);">
                                <div class="<?php echo e((isset($program->image)  && ($program->image != "")) ? "" : "formid_cqw"); ?>">
                                    <?php if(isset($program->image) && ($program->image != "" )): ?> 
                                    <img src="<?php echo e($program->image); ?>" id="programImage">
                                    <?php else: ?>
                                    <span><img src="<?php echo e(asset('images/icon-upload.svg')); ?>" id="programImage"></span>
                                    <p>Upload photo</p>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                        <input type="file" name="program_image" class="profilePic">
                        <div class="for_right_name">
                        <?php if(isset($id)): ?>
                            <h5><?php echo e(isset($organization->program_label) ? $organization->program_label : 'Program'); ?></h5>
                            <h2><?php echo e(isset($program->name) ? $program->name : null); ?></h2>
                        <?php endif; ?>  
                        </div>
                    </div>
                </div>
        		<div class="col-sm-6">
        			<div class="right_bar_top_profile">
        				<!-- <h4><a id="closed" href="javascript:void(0)"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></h4> -->
                       
                          <?php if(!isset($org_id)): ?>
                             <h4><a href="javascript:void(0);" id="closed1"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></h4>
                            <input type="hidden" id="back_url" name="url" value="<?php echo e(route('program.index')); ?>">
                        <?php else: ?>
                           <input type="hidden" id="back_url" name="url" value="<?php echo e(route('organization.edit', array($org_id))); ?>">
                            <h4><a href="javascript:void(0);" id="closed"><img src="<?php echo e(asset('images/icon-close.svg')); ?>"></a></h4>
                        <?php endif; ?>
        					<input type="submit" class="btn-cls mrg-top float-right" value="Save Changes">
        				</h4>
        			</div>
        		</div>
        	</div>
        </div>

        <div class="full_width Tabs_cls_cool marg40">
            <nav>
                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                    <a class="nav-item nav-link active" id="nav-details-tab" data-toggle="tab" href="#nav-details" role="tab" aria-controls="nav-details" aria-selected="true">Details</a>
                    <?php if(isset($id)): ?>                                        
                        <a class="nav-item nav-link" id="nav-supervisors-tab" data-toggle="tab" href="#nav-supervisors" role="tab" aria-controls="nav-supervisors" aria-selected="false"><?php echo e(isset($organization->supervisor_label) ? $organization->supervisor_label.'s' : 'Supervisors'); ?></a>
                        <a class="nav-item nav-link" id="nav-providers-tab" data-toggle="tab" href="#nav-providers" role="tab" aria-controls="nav-providers" aria-selected="false"><?php echo e(isset($organization->provider_label) ? $organization->provider_label.'s' : 'Providers'); ?></a>
                        <a class="nav-item nav-link" id="nav-users-tab" data-toggle="tab" href="#nav-users" role="tab" aria-controls="nav-users" aria-selected="false"><?php echo e(isset($organization->participant_label) ? $organization->participant_label.'s' : 'Participants'); ?></a>
                        <a class="nav-item nav-link" id="nav-goals-tab" data-toggle="tab" href="#nav-goals" role="tab" aria-controls="nav-goals" aria-selected="false">
                        Goals</a>
                    <?php endif; ?>
                    <a class="nav-item nav-link" id="nav-notes-tab" data-toggle="tab" href="#nav-notes" role="tab" aria-controls="nav-notes" aria-selected="false">Notes</a>
                </div>
               <!--  <div class="for_ty_export"><a href="javascript:void(0);"><img src="<?php echo e(asset('images/export.png')); ?>"> <span>Export program’s Data</span></a></div> -->
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-details" role="tabpanel" aria-labelledby="nav-details-tab">
                    <?php echo $__env->make('program.partials._add-edit-details-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php if(isset($id)): ?>      
                    <div class="tab-pane fade" id="nav-supervisors" role="tabpanel" aria-labelledby="nav-supervisors-tab">
                        <?php echo $__env->make('program.partials._add-edit-supervisors-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane fade" id="nav-providers" role="tabpanel" aria-labelledby="nav-providers-tab">
                        <?php echo $__env->make('program.partials._add-edit-providers-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    </div>
                    <div class="tab-pane fade" id="nav-users" role="tabpanel" aria-labelledby="nav-users-tab">
                        <?php echo $__env->make('program.partials._add-edit-users-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                    </div>
                     <div class="tab-pane fade" id="nav-goals" role="tabpanel" aria-labelledby="nav-goals-tab">
                        <?php echo $__env->make('program.partials._add-edit-goals-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                    </div>
                <?php endif; ?>
                <div class="tab-pane fade" id="nav-notes" role="tabpanel" aria-labelledby="nav-notes-tab">
                    <?php echo $__env->make('program.partials._add-edit-notes-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    <?php echo e(Form::close()); ?>    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/program/add_edit.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/program/supervisor/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/program/provider/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/program/user/index.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/pages/program/goal/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-without-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/program/add-edit.blade.php ENDPATH**/ ?>