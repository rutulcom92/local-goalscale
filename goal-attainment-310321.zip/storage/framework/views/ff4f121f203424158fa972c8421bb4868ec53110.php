<div class="goal_box_item_cls">
    <h4 class="titleheadgoal">Scaling</h4>
    <div class="for_scaling_box_listing">
        <ul>
            <?php $__currentLoopData = goalScale(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <span><?php echo e($value); ?></span>
                    <p>
                        <textarea class="dectextarea goal-scale-description" placeholder="Enter description..." name="goal[scale][<?php echo e($key); ?>]"></textarea>
                    </p>
                </li>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/goal/create/_scaling.blade.php ENDPATH**/ ?>