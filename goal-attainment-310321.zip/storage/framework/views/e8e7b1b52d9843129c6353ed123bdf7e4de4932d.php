

<?php $__env->startSection('title','WMU | Log Events'); ?>

<?php $__env->startSection('content'); ?>
<div class="Wrap_all_class">
     <div class="Wrap_all_class_inner">
        <div class="top_filter formobile_screen">
        	<div class="row">
        		<div class="col-sm-2">
        			<h1>Log Events</h1>
        		</div>
        		<div class="col-sm-10">
        			<div class="filter_cls_wmu">
        				<ul class="eventsDt-custom-filters">
							<li class="mrg-left wdth100">
								<input type="text" name="event_to_date" class="input_clso datepicker-element org-dreport-filter datatable-custom-filter" placeholder="To Date" data-placeholder="" data-table-id="eventsDt">
							</li>
							<li class="mrg-left wdth100">
								<input type="text" name="event_from_date" class="input_clso datepicker-element org-dreport-filter datatable-custom-filter" placeholder="From Date" data-placeholder="" data-table-id="eventsDt">
							</li>
							<li class="mrg-left wdth">
        						<select class="element_select datatable-custom-filter" data-table-id="eventsDt" name="userType">
        							<option value="">Filter by User Type</option>
        							<?php $__currentLoopData = $userTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        						</select>
        					</li>
							<li class="mrg-left wdth">
        						<select class="element_select datatable-custom-filter" data-table-id="eventsDt" name="eventName">
        							<option value="">Filter by Event Name</option>
        							<?php $__currentLoopData = $eventNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        						</select>
        					</li>
                            <li class="mrg-left wdth150">
        						<select class="element_select datatable-custom-filter" data-table-id="eventsDt" name="eventType">
        							<option value="">Filter by Event Type</option>
        							<?php $__currentLoopData = $eventTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        						</select>
        					</li>
                            <li class="mrg-left wdth">
        						<input type="text" placeholder="Search" class="input_clso srch datatable-common-search-input" data-table-id="eventsDt">
        					</li>
        				</ul>
        			</div>
        		</div>
        	</div>
        </div>
        <div class="for_content_section">
            <?php echo $__env->make('loaders.datatables-inner-loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        	<!-- <table class="table dt-responsive nowrap" id="eventsDt" style="width:100%" data-ajax-url="<?php echo e(route('event.list')); ?>"> -->
            <table id="eventsDt" class="table dt-responsive nowrap event-tbl" style="width:100%" data-ajax-url="<?php echo e(route('event.list')); ?>">
        		<thead>
        			<tr>
						<th>Event Type</th>
						<th>Event Name</th>
                        <th>Description</th>
						<th>Related ID</th>
						<th>Email</th>
        				<th>Event User Type</th>
        				<th>Event User Name</th>
        				<th>Created At</th>
        				<!-- <th>Actions</th> -->
        			</tr>
        		</thead>
        		<tbody>
        		</tbody>
        	</table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/pages/event/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/event/index.blade.php ENDPATH**/ ?>