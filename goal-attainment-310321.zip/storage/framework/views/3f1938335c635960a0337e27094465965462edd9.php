<div class="datatables-inner-loader">
    <i class='fas fa-circle-notch fa-spin'></i>
</div><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/loaders/datatables-inner-loader.blade.php ENDPATH**/ ?>