<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('images/wmu_favicon.png')); ?>" type="image/png" sizes="32x32">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link href="https://pro.fontawesome.com/releases/v5.1.0/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,900&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jquery.mCustomScrollbar.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/iziToast.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-multiselect.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <script type="text/javascript">
        var base_url = "<?php echo e(url('/')); ?>";
    </script>
</head>
<body>
    <div class="loader">
        <span class="dashboard-spinner spinner-md"></span>
    </div>
    <header class="header_cl">
        <div class="web_logo">
            <a href="<?php echo e(url('/')); ?>"><img id="web-logo-image" width="58" height="58" src="<?php echo e(asset('images/gas-logo.png')); ?>"></a>
        </div>
        <?php if(Auth::user()->user_type_id == organizationAdminUserTypeId() || Auth::user()->user_type_id == superAdminUserTypeId()): ?>
            <div class="upload_logo_UI">
             <?php echo e(Form::open(array('route' => array('dashboard.image-upload', Auth::user()->id), 'id' => 'userForm'))); ?>

             <?php echo method_field('PUT'); ?>
                <?php if(!empty(Auth::user()->logo_image)): ?>
                    <a href="javascript:void(0);" id="userlogo" class="web-logo-change">
                        <img src="<?php echo e(Auth::user()->logo_image); ?>" id="user-logo-image" accept="image/*" style="height: 97%;width: 99%;filter: none;object-fit: cover;">
                    </a>
                <?php else: ?>
                    <a href="javascript:void(0);" id="userlogo" class="web-logo-change">
                        <img src="<?php echo e(asset('images/icon-upload.svg')); ?>" id="user-logo-image" accept="image/*"><span>Upload your own logo</span>
                    </a>
                <?php endif; ?>
            <?php echo e(Form::close()); ?>  
            </div>
            <input type="file" name="logo_image" id="user-logo" style="display: none;">
        <?php endif; ?>

        <div class="menu_right_header"> 
            <div class="sec_mobile_menuTo">
                <a href="javascript:void(0);" class="toggle_menuswp"><i class="fas fa-bars"></i></a>
                <ul class="formob_device">
                    <li class="<?php echo e((request()->is('dashboard')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessProgramModule')): ?>
                        <li class="<?php echo e((request()->is('program')) ? 'active' : ''); ?>"><a href="<?php echo e(route('program.index')); ?>">Programs</a></li>
                    <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessOrganizationModule')): ?> 
                        <li class="<?php echo e((request()->is('organization')) ? 'active' : ''); ?>"><a href="<?php echo e(route('organization.index')); ?>">Organizations</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessSupervisorModule')): ?>        
                        <li class="<?php echo e((request()->is('supervisor')) ? 'active' : ''); ?>"><a href="<?php echo e(route('supervisor.index')); ?>">Supervisors = <?php echo e(\App\Models\Organization::where(['id' => Auth::user()->organization_id])->pluck('supervisor_label')->first()); ?></a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessProviderModule')): ?>
                        <li class="<?php echo e((request()->is('provider')) ? 'active' : ''); ?>"><a href="<?php echo e(route('provider.index')); ?>">Providers</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessParticipantModule')): ?>
                        <li class="<?php echo e((request()->is('participant')) ? 'active' : ''); ?>"><a href="<?php echo e(route('participant.index')); ?>">Participants</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessGoalModule')): ?>
                        <li class="<?php echo e((request()->is('goal')) ? 'active' : ''); ?>"><a href="<?php echo e(route('goal.index')); ?>">Goals</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessReportModule')): ?>
                        <li class="<?php echo e((request()->is('reports')) ? 'active' : ''); ?>"><a href="<?php echo e(route('reports')); ?>">Reports</a></li>
                    <?php endif; ?>
                </ul>
            </div>           
            <div class="topbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="javascript:void(0);" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="img-profile rounded-circle" src="<?php echo e(!empty(Auth::user()->image) ? Auth::user()->image : ''); ?>">
                    <span class="d-none d-lg-inline"><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></span>
                </a>
                <!-- Here's the magic. Add the .animate and .slide-in classes to your .dropdown-menu and you're all set! -->
                <div class="dropdown-menu dropdown-menu-right animate slideIn" aria-labelledby="navbarDropdown">
                    <?php if(Auth::user()->user_type_id == 4): ?>
                        <a class="dropdown-item" href="<?php echo e(route('participant.profile.index')); ?>">My Account</a>
                    <?php elseif(Auth::user()->user_type_id == 3): ?>
                        <a class="dropdown-item" href="<?php echo e(route('provider.profile.index')); ?>">My Account</a>
                    <?php elseif(Auth::user()->user_type_id == 2): ?>
                        <a class="dropdown-item" href="<?php echo e(route('supervisor.profile.index')); ?>">My Account</a>
                    <?php else: ?>    
                        <a class="dropdown-item" href="<?php echo e(route('admin.profile.index')); ?>">My Account</a> 
                    <?php endif; ?>

                    <?php if(Auth::user()->isSuperAdmin() || Auth::user()->isOrganizationAdmin()): ?>
                        <a class="dropdown-item" href="<?php echo e(route('event.index')); ?>">Event Logs</a>
                    <?php endif; ?>

                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Sign Out</a>
                </div>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                </form>
                </li>
            </ul>
            </div>
            <div class="top_sec_menu">               
                <ul class="fordesk_device">
                    <li class="<?php echo e((request()->is('dashboard')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessProgramModule')): ?>
                        <li class="<?php echo e((request()->is('program')) ? 'active' : ''); ?>"><a href="<?php echo e(route('program.index')); ?>"><?php if(Auth::user()->isSuperAdmin()): ?> Programs <?php else: ?> <?php echo e(\App\Models\Organization::where(['id' => Auth::user()->organization_id])->pluck('program_label')->first()); ?>s <?php endif; ?></a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessOrganizationModule')): ?>
                        <li class="<?php echo e((request()->is('organization')) ? 'active' : ''); ?>"><a href="<?php echo e(route('organization.index')); ?>">Organizations</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessSupervisorModule')): ?>        
                        <li class="<?php echo e((request()->is('supervisor')) ? 'active' : ''); ?>"><a href="<?php echo e(route('supervisor.index')); ?>"><?php if(Auth::user()->isSuperAdmin()): ?> Supervisors <?php else: ?> <?php echo e(\App\Models\Organization::where(['id' => Auth::user()->organization_id])->pluck('supervisor_label')->first()); ?>s <?php endif; ?></a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessProviderModule')): ?>
                        <li class="<?php echo e((request()->is('provider')) ? 'active' : ''); ?>"><a href="<?php echo e(route('provider.index')); ?>"><?php if(Auth::user()->isSuperAdmin()): ?> Providers <?php else: ?> <?php echo e(\App\Models\Organization::where(['id' => Auth::user()->organization_id])->pluck('provider_label')->first()); ?>s <?php endif; ?></a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessParticipantModule')): ?>
                        <li class="<?php echo e((request()->is('participant')) ? 'active' : ''); ?>"><a href="<?php echo e(route('participant.index')); ?>"><?php if(Auth::user()->isSuperAdmin()): ?> Participants <?php else: ?> <?php echo e(\App\Models\Organization::where(['id' => Auth::user()->organization_id])->pluck('participant_label')->first()); ?>s <?php endif; ?></a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessGoalModule')): ?>
                        <li class="<?php echo e((request()->is('goal')) ? 'active' : ''); ?>"><a href="<?php echo e(route('goal.index')); ?>">
                            <?php if(Auth::user()->user_type_id == 4): ?>
                                My Goals
                            <?php else: ?>
                                Goals
                            <?php endif; ?>
                        </a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessReportModule')): ?>
                        <li class="<?php echo e((request()->is('reports')) ? 'active' : ''); ?>"><a href="<?php echo e(route('reports')); ?>">Reports</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </header>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="footer">
        <span class="footer-text">© <?php echo e(config('constants.FOOTER_APP_NAME')); ?> <?php echo e(date('Y')); ?></span>
    </div>
    <div id="bsModalContent"></div>
</body>
    

<!-- All Scripts -->
<script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/dataTables.scroller.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/jquery.mCustomScrollbar.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/moment.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('js/iziToast.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/highcharts.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-multiselect.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/general.js')); ?>" type="text/javascript"></script>
<!-- <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->
<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    jQuery(document).ready(function() {
        jQuery(".toggle_menuswp").click(function(){
            jQuery(".sec_mobile_menuTo").toggleClass("menushw_showmob");
        });
    });

    $(document).ready(function () {
        $('.dropdown-toggle').dropdown();
    });
    
    <?php if(Session::has('success')): ?>
        commonScripts._toastSuccess("<?php echo e(Session::get('success')); ?>");;
    <?php endif; ?>
</script>
<?php echo $__env->yieldContent('extra'); ?>
</html><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/layouts/app.blade.php ENDPATH**/ ?>