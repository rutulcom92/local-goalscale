<div class="Wrap_all_classx">
    <div class="Wrap_all_class_innerx">
		<div class="mb-5">
			<div class="card col-md-12">
				<div class="card-body">
					<div class="text-center">
						<span class="h5">Below users data will be imported.</span>						
						<div class="pop_hd_btn mt-2">
							<button type="button" data-import-users-ajax-url="<?php echo e(route('user.import.post')); ?>" class="import-continue btn-cls">Continue</button>
							<!-- <button type="button" class="close btn-cls dlminwidthy" data-dismiss="modal">Cancel</button> -->
						</div>
					</div>
				</div>
			</div>
		</div>
        <div class="for_content_section mb-5">
        	<table id="goalsDtImp" class="table dt-responsive nowrap goal-import-tbl" style="width:100%">
				<thead>
        			<tr>
        				<th>First Name</th>
        				<th>Last Name</th>
        				<th>User Type</th>
        				<th>Email</th>
						<th>Password</th>
        				<th>Phone</th>
        				<th>Address</th>
        				<th>City</th>
        				<th>State</th>
						<th>Zip</th>
						<th>Organization</th>
        			</tr>
        		</thead>
				<tbody>
					<?php $__currentLoopData = $importdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e(isset($value['first_name'])?$value['first_name']:''); ?></td>
							<td><?php echo e(isset($value['last_name'])?$value['last_name']:''); ?></td>
							<td><?php echo e(isset($value['user_type'])?$value['user_type']:''); ?></td>
							<td><?php echo e(isset($value['email'])?$value['email']:''); ?></td>
							<td><?php echo e(isset($value['password'])?$value['password']:''); ?></td>
							<td><?php echo e(isset($value['phone'])?$value['phone']:''); ?></td>
							<td><?php echo e(isset($value['address'])?$value['address']:''); ?></td>
							<td><?php echo e(isset($value['city'])?$value['city']:''); ?></td>
							<td><?php echo e(isset($value['state'])?$value['state']:''); ?></td>
							<td><?php echo e(isset($value['zip'])?$value['zip']:''); ?></td>
							<td><?php echo e(isset($value['organization'])?$value['organization']:''); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</tbody>
        	</table>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\goal-attainment\resources\views/user/importdata.blade.php ENDPATH**/ ?>