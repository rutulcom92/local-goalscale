<div class="form_field_cls part_sec">
  	<div class="full_width">
      	<div class="row">
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('First Name *')); ?>

          			<?php echo e(Form::text('users[first_name]', isset($participant->first_name) ? $participant->first_name : null, array('class'=>'input_control','placeholder'=>'First name'))); ?>

          		</div>
      		</div>
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Last Name *')); ?>

          			<?php echo e(Form::text('users[last_name]', isset($participant->last_name) ? $participant->last_name : null, array('class'=>'input_control','placeholder'=>'Last name'))); ?>

          		</div>
      		</div>
      		</div>
      	</div>

		<div class="full_width">
      	<div class="row">
       	   <div class="col-sm-3">
      		<div class="form-group">
      			<?php echo e(Form::label('Organization *')); ?>

                <select name="users[organization_id]" placeholder="Please Select"  class="element_select participant_organization" data-get-participant-programs-ajax-url = <?php echo e(route("participant.get-organization-programs")); ?> >
                    <option value="">Please select</option>
                    <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == $org_id): ?>
                            <option value="<?php echo e($key); ?>" selected="selected"><?php echo e($val); ?></option>
                        <?php elseif($key == $selected_organization): ?>
                            <option value="<?php echo e($key); ?>" selected="selected"><?php echo e($val); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
      		</div>
        </div>
        <div class="col-sm-3">
        		<div class="form-group">
				<?php echo e(Form::label(isset($organization->program_label) ? $organization->program_label.' *' : 'Program *')); ?>

                    <input type="hidden" name="pid" value="<?php echo e($pid); ?>" id="pid">
      				<select name="user_programs[program_id][]" class="multi_select_element sel_programs participant_programs" multiple="multiple" data-tags="true" data-placeholder="Please Select" data-get-participant-providers-ajax-url = <?php echo e(route("participant.get-programs-providers")); ?>>
        					<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($key == $pid): ?>
                      <option value="<?php echo e($key); ?>" selected="selected"><?php echo e($val); ?></option>
        						<?php elseif(in_array($key,$selected_programs)): ?>
        							<option value="<?php echo e($key); ?>" selected="selected"><?php echo e($val); ?></option>
        						<?php else: ?>
        							<option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
        						<?php endif; ?>
        					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      				</select>
        		</div>
  	 	  </div>
     	</div>
     </div>
      <div class="full_width">
        <div class="row select-providers">
          <?php if(!isset($id)): ?>
            <div class="col-sm-3">
                <div class="form-group">
                  <?php echo e(Form::label('Provider *')); ?>

                    <select name="participant_provider[provider_id][]" class="select2-element sel_providers" placeholder="Please Select" id="participant_provider_0" multiple="multiple">
                        <option value="">Please Select</option>
                        <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
            </div>
          <?php else: ?>
            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-3">
                <div class="form-group">
                <?php echo e(Form::label($val['program_name'].' Provider *')); ?>

                  <select name="participant_provider[provider_id][]" class="select2-element sel_providers" placeholder="Please Select" id="participant_provider_<?php echo e($val['program_id']); ?>" multiple="multiple"> 
                    <option value="">Please Select</option>
                    <?php $__currentLoopData = $val['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(!empty($selected_provider->where('program_id',$val['program_id'])->where('provider_id',$provider->id)->first())): ?>
                        <option selected="selected" value="<?php echo e($provider->id); ?>,<?php echo e($val['program_id']); ?>"><?php echo e($provider->full_name); ?></option>
                      <?php else: ?>
                        <option value="<?php echo e($provider->id); ?>,<?php echo e($val['program_id']); ?>"><?php echo e($provider->full_name); ?></option>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php endif; ?>
        </div>
      </div>
  	<div class="full_width">
      	<div class="row">
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Email *')); ?>

          			<?php echo e(Form::text('users[email]', isset($participant->email) ? $participant->email : null, array('class'=>'input_control','id'=>'participantEmail','placeholder'=>'Email'))); ?>

          		</div>
      		</div>
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Phone *')); ?>

          			<?php echo e(Form::text('users[phone]', isset($participant->phone) ? $participant->phone : null, array('class'=>'input_control mobile-input-mask','placeholder'=>'Phone'))); ?>

          		</div>
      		</div>
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Date of Birth *','Date of Birth *')); ?>

          			<?php echo e(Form::text('userDetail[dob]', isset($participantDetail->dob) ? mdyDateFormate($participantDetail->dob) : null, array('class'=>'input_control dob-datepicker-element'))); ?>

          		</div>
      		</div>
      	</div>
  	</div>
  	<div class="full_width">
  		<div class="row">
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Address *')); ?>

          			<?php echo e(Form::text('users[address]', isset($participant->address) ? $participant->address : null, array('class'=>'input_control','placeholder'=>'Address'))); ?>

          		</div>
      		</div>
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('City *')); ?>

          			<?php echo e(Form::text('users[city]', isset($participant->city) ? $participant->city : null, array('class'=>'input_control','placeholder'=>'City'))); ?>

          		</div>
      		</div>
      		<div class="col-sm-3">
          		<div class="form-group">
      			<?php echo e(Form::label('State *')); ?>

      			<?php echo e(Form::select('users[state_id]', ['' => 'Please Select']+ $states->toArray(), isset($participant->state_id) ? $participant->state_id : null ,array('class' => 'element_select'))); ?>

          		</div>
      		</div>
  		</div>
  	</div>
  	<div class="full_width">
  		<div class="row">
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Zip *')); ?>

          			<?php echo e(Form::text('users[zip]', isset($participant->zip) ? $participant->zip : null, array('class'=>'input_control zip-input-mask','placeholder'=>'Zip'))); ?>

          		</div>
      		</div>
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Record # (add N/A if not applicable)')); ?>

          			<?php echo e(Form::text('users[record_num]', isset($participant->record_num) ? $participant->record_num : 0, array('class'=>'input_control','placeholder'=>'Record'))); ?>

          		</div>
      		</div>
      		<div class="col-sm-3">
          		<div class="form-group">
          			<?php echo e(Form::label('Gender *')); ?>

          			<div class="full_width">
              			<div class="half_radio_cl">
                          <div class="custom_radio">
                           <?php echo e(Form::radio('userDetail[gender]','M',isset($participantDetail->gender) ? ($participantDetail->gender == "M") ? "checked" : "" : "",array('id' => 'test6'))); ?>

                            <label for="test6">Male</label>
                          </div>
                    	</div>
                    	<div class="half_radio_cl">
                          <div class="custom_radio">
                           <?php echo e(Form::radio('userDetail[gender]','F',isset($participantDetail->gender) ? ($participantDetail->gender == "F") ? "checked" : "" : "",array('id' => 'test7'))); ?>

                            <label for="test7">Female</label>
                          </div>
                    	</div>
                    	<div class="half_radio_cl">
                          <div class="custom_radio">
                            <?php echo e(Form::radio('userDetail[gender]','O', isset($participantDetail->gender) ? ($participantDetail->gender == "O") ? "checked" : "" : "",array('id' => 'test8'))); ?>

                            <label for="test8">Other</label>
                          </div>
                    	</div>
                	</div>
                	<span id="gendor_error"></span>
          		</div>
      		</div>
  		</div>
  	</div>
	<div class="full_width">
		<div class="row">
			<div class="col-sm-3">
				<div class="form-group">
					<?php echo e(Form::label('Race/Ethnicity')); ?>

					<?php echo e(Form::select('users[ethnicity]', ['' => 'Please Select','American Indian Or Alaska Native' => 'American Indian Or Alaska Native','Asian' => 'Asian','Black Or African American' => 'Black Or African American','Hispanic Or Latino' => 'Hispanic Or Latino','I Don\'t Wish To Answer' => 'I Don\'t Wish To Answer','Native Hawaiian Or Other Pecific Islander' => 'Native Hawaiian Or Other Pecific Islander','Two Or More Races' => 'Two Or More Races','White' => 'White'], isset($participant->ethnicity) ? $participant->ethnicity : null ,array('class' => 'element_select'))); ?>

				</div>
			</div>
		</div>
	</div>
  	<div class="full_width separator_div"></div>
  	<?php if(isset($id)): ?>
  	<div class="full_width forgot_pass">
  		<div class="row">
  			<div class="col-sm-3">
          		<h6>Set Password</h6>
          		<div class="form-group marg13">
          			<?php echo e(Form::label('Set Password')); ?>

          			<input type="password" name ="users[password]" class="input_control marg13" placeholder="New password"  autocomplete="new-password">
          			<input type="password" name ="password_confirmation"  class="input_control" placeholder="Confirm new password">
          		</div>
      		</div>
  		</div>
  	</div>
    <?php if(Auth::user()->isSuperAdmin() == true  || Auth::user()->isOrganizationAdmin()): ?>
      <div class="full_width">
        <div class="row">
            <div class="col-sm-6">
              <div class="full_width">
                    <div class="custom-control custom-checkbox dfg ">
                          <label class="custom-control custom-checkbox">
                              <input type="checkbox" class="custom-control-input business_To p_view " name="inactive_user" value="1" <?php if($participant->is_active == 0): ?> checked="" <?php endif; ?>>
                              <span class="custom-control-indicator"></span>
                              <div class="custom-control-description">User Inactive</div>
                          </label>
                      </div>
                  </div>
            </div>
          </div>
      </div>
    <?php endif; ?>
  	<?php else: ?>
  	<div class="full_width">
  		<div class="row">
      		<div class="col-sm-6">
      			<div class="full_width">
              		<div class="custom-control custom-checkbox dfg ">
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input business_To p_view " name="user_set_password" value="1" checked="">
                            <span class="custom-control-indicator"></span>
                            <div class="custom-control-description">Send the new user an email about their account and a password reset link</div>
                        </label>
                    </div>
                </div>
      		</div>
      	</div>
  	</div>
  	<?php endif; ?>
</div>
<?php /**PATH C:\wamp64\www\goal-attainment\resources\views/participant/partials/_add-edit-profile-section.blade.php ENDPATH**/ ?>