<?php $__currentLoopData = $supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-sm-3">
	<div class="form-group">
	<?php echo e(Form::label(isset($organization->supervisor_label) ? $organization->supervisor_label .' : '. $val['program_name'].' *' : 'Supervisor : '. $val['program_name'].' *')); ?>

		<select name="provider_supervisor[supervisor_id][]" class="multi_select_element select2-element sel_supervisor" data-placeholder="Please Select" id="provider_supervisor_<?php echo e($val['program_id']); ?>" multiple="multiple"> 
			<option>Please Select</option>
			<?php $__currentLoopData = $val['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($supervisor->id); ?>,<?php echo e($val['program_id']); ?>"><?php echo e($supervisor->full_name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\goal-attainment\resources\views/provider/select-provider-supervisors.blade.php ENDPATH**/ ?>