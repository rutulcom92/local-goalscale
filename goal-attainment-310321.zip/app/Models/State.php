<?php

namespace App\Models;

use App\BaseModel;

class State extends BaseModel
{
    protected $table = 'states';

    protected $primaryKey = 'id';
}
